//
//  main.swift
//  userutil
//
//  Created by Egor Devyatov on 16.07.2019.
//  Copyright © 2019 Egor Devyatov. All rights reserved.
//

import Foundation

print("Hello, World!")

